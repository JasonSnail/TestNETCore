﻿using System;
using System.Diagnostics;
using System.Threading;
using System.Threading.Tasks;
using Newtonsoft;

namespace TestCore
{
    class Program
    {
        public static int tCount = 5;

        static async Task Main(string[] args)
        {
            Console.WriteLine("Hello World!2222");

            CancellationTokenSource cts = new CancellationTokenSource();
            CancellationToken token = cts.Token;

            var aa = new TestTaskAsync();
            Task task1 = Task.Run(() => new TestTaskAsync().Execute(token), token);
            //Task<int> task1 = Task.Run<int>(() => aa.ToastBreadAsync(5));
            //Task task1 = Task.Run(() => aa.ToastBreadAsync(5));

            // Test cancel task
            Thread.Sleep(2000);
            cts.Cancel();
                
            try
            {
                Task.WaitAll(new Task[] { task1 }, millisecondsTimeout:5000, cancellationToken: token);
            }
            catch (OperationCanceledException e)
            {
                Console.WriteLine($"Task was cancelled: {e.Message}");
            }

            if (task1.IsCompleted)
            {
                Console.WriteLine("Task completed successfully ...");
            } else {
                Console.WriteLine("Task faulted ...");
            }

            Console.WriteLine("Hello World!33333");
            //Console.WriteLine($"Task Result: {task1.Result}");
        }

        private string GetDebuggerDisplay()
        {
            return ToString();
        }
    }

     class TestTaskAsync
    {
        public async Task Execute(CancellationToken token)
        {
            try
            {
                var testTask = ToastBreadAsync(Program.tCount, token);
                token.ThrowIfCancellationRequested();
                await testTask;
                Console.WriteLine("Hello World!4444");
            } catch (AggregateException e)
            {
                Console.WriteLine($"Occurred Exception: {e.InnerException}");
            }

        }

        public async Task<int> ToastBreadAsync(int slices, CancellationToken token)
        {
            token.ThrowIfCancellationRequested();
            for (int slice = 0; slice < slices; slice++)
            {
                Console.WriteLine("Putting a slice of bread in the toaster");
            }
            Console.WriteLine("Start toasting...");
            await Task.Delay(3000);
            Console.WriteLine("Remove toast from toaster");

            return 1;
        }
    }
}
