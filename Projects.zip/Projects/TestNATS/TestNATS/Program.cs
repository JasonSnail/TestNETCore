﻿using System;
using System.Text;
using NATS.Client;

namespace TestNATS_Pub
{
    class Program
    {
        static void Main(string[] args)
        {
            new NATS_Publish().Execute();

            Console.WriteLine("Execute NATS Publisher ...");
        }
    }

    class NATS_Publish
    {
        int count = 1;
        string url = Defaults.Url;
        string subject = "foo";
        byte[] payload = null;
        string creds = null;

        public void Execute()
        {
            Options opts = ConnectionFactory.GetDefaultOptions();
            opts.Url = url;
            if (creds != null)
            {
                opts.SetUserCredentials(creds);
            }

            using (IConnection c = new ConnectionFactory().CreateConnection(opts))
            {
                c.Publish(subject, Encoding.UTF8.GetBytes("Hello World"));
            }
        }
    }


}
