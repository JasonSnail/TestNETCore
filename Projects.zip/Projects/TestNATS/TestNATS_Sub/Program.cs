﻿using System;
using System.Threading;
using System.Threading.Tasks;
using NATS.Client;

namespace TestNATS_Sub
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Execute NATS Subscriber ...");
            var main_task = new NATS_Subscriber().Execute();
            Console.ReadKey();
        }
    }

    class NATS_Subscriber
    {
        int count = 1;
        string url = Defaults.Url;
        string subject = "foo";
        byte[] payload = null;
        string creds = null;

        public async Task Execute()
        {
            Options opts = ConnectionFactory.GetDefaultOptions();
            opts.Url = url;
            if (creds != null)
            {
                opts.SetUserCredentials(creds);
            }

            CancellationTokenSource cts = new CancellationTokenSource();
            CancellationToken token = cts.Token;

            using (IConnection c = new ConnectionFactory().CreateConnection(opts))
            {
                Task task1 = Task.Run(() => ReceiveSubAsync(c, token), token);
                await task1;
            }
        }

        EventHandler<MsgHandlerEventArgs> msgHandler = (sender, args) =>
        {
            Console.WriteLine("Received: " + args.Message);
        };

        private async Task ReceiveSubAsync(IConnection c, CancellationToken token)
        {
            while (!token.IsCancellationRequested)
            {
                IAsyncSubscription s = c.SubscribeAsync(subject, msgHandler);
                Thread.Sleep(2000);
                s.Unsubscribe();
                //using (IAsyncSubscription s = c.SubscribeAsync(subject, msgHandler))
                //{
                //}
            }
        }
    }
}
