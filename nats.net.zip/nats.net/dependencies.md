# External Dependencies

This file lists the dependencies used in this repository.

| Dependency | License |
|-|-|
| NETStandard.Library (A)  [1.6.1, )  1.6.1 | MIT |
| System.Net.Security 4.3.2  4.3.2 | MIT |
| System.Reflection.Extensions  4.3.0  4.3.0 | MIT |
| System.Runtime  4.3.1  4.3.1 | MIT |
| System.Threading.Thread 4.3.0  4.3.0 | MIT |
| Microsoft.NET.Test.Sdk         16.4.0      16.4.0 | MIT |
| xunit                          2.4.1       2.4.1 | Apache 2.0 License |
| xunit.runner.visualstudio      2.4.1       2.4.1 | Apache 2.0 License |
| Nito.AsyncEx                   5.0.0       5.0.0 | MIT |
| BenchmarkDotNet 0.12.0 0.12.0 | MIT |
