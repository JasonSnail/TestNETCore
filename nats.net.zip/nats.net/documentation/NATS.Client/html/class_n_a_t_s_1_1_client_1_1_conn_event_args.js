var class_n_a_t_s_1_1_client_1_1_conn_event_args =
[
    [ "Conn", "class_n_a_t_s_1_1_client_1_1_conn_event_args.html#a11345de0669fdcfe2fae5fccf96acf29", null ],
    [ "Error", "class_n_a_t_s_1_1_client_1_1_conn_event_args.html#a83a9998fd0824b3c326ecfbeba99b435", null ]
];