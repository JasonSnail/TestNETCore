var class_n_a_t_s_1_1_client_1_1_encoded_message_event_args =
[
    [ "Message", "class_n_a_t_s_1_1_client_1_1_encoded_message_event_args.html#addeff0383437b18da543e4feb616f591", null ],
    [ "ReceivedObject", "class_n_a_t_s_1_1_client_1_1_encoded_message_event_args.html#a06e10df22a57ef596cb5f7fb411a684a", null ],
    [ "Reply", "class_n_a_t_s_1_1_client_1_1_encoded_message_event_args.html#a4f98b1a3fe115f6a42a1010917690020", null ],
    [ "Subject", "class_n_a_t_s_1_1_client_1_1_encoded_message_event_args.html#a7c94d34c05f3c023a55ade85b3045b93", null ]
];