var class_n_a_t_s_1_1_client_1_1_err_event_args =
[
    [ "Conn", "class_n_a_t_s_1_1_client_1_1_err_event_args.html#ad1598c7dfa6baf450c354006b5cac291", null ],
    [ "Error", "class_n_a_t_s_1_1_client_1_1_err_event_args.html#aaf69826de4c5910c4b4a2f4f5d5f36c9", null ],
    [ "Subscription", "class_n_a_t_s_1_1_client_1_1_err_event_args.html#aeef5125e932399ea19207dfd20598fb8", null ]
];