var class_n_a_t_s_1_1_client_1_1_statistics =
[
    [ "InBytes", "class_n_a_t_s_1_1_client_1_1_statistics.html#a05c477b2f999fe862739c7c608e83c69", null ],
    [ "InMsgs", "class_n_a_t_s_1_1_client_1_1_statistics.html#a3ba3c1577ac461228e35c7dab8334a6c", null ],
    [ "OutBytes", "class_n_a_t_s_1_1_client_1_1_statistics.html#a4b6011dbbb64f5262b83f4eaea55e834", null ],
    [ "OutMsgs", "class_n_a_t_s_1_1_client_1_1_statistics.html#af35f62b148cc439f953f4dd5b5707175", null ],
    [ "Reconnects", "class_n_a_t_s_1_1_client_1_1_statistics.html#ac2ef96188900a4921e5a4f1f8980ca32", null ]
];