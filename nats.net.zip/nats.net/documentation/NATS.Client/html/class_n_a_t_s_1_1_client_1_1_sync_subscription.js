var class_n_a_t_s_1_1_client_1_1_sync_subscription =
[
    [ "NextMessage", "class_n_a_t_s_1_1_client_1_1_sync_subscription.html#acc4f7d714e2bc1c37d6a7e2f033d2443", null ],
    [ "NextMessage", "class_n_a_t_s_1_1_client_1_1_sync_subscription.html#a9289d58d9671fa0d49ec40b498f3fa13", null ]
];