var class_n_a_t_s_1_1_client_1_1_user_signature_event_args =
[
    [ "ServerNonce", "class_n_a_t_s_1_1_client_1_1_user_signature_event_args.html#af6339c8ed1da8ae5e40a96eca3bcf0aa", null ],
    [ "SignedNonce", "class_n_a_t_s_1_1_client_1_1_user_signature_event_args.html#a97373aad4003bdce16205d1d8d3e8f78", null ]
];