var interface_n_a_t_s_1_1_client_1_1_i_statistics =
[
    [ "InBytes", "interface_n_a_t_s_1_1_client_1_1_i_statistics.html#ad9fbd5ee688b23449991d2a3abc0c7ea", null ],
    [ "InMsgs", "interface_n_a_t_s_1_1_client_1_1_i_statistics.html#a57a64591aa59219d379a8074479d0dbb", null ],
    [ "OutBytes", "interface_n_a_t_s_1_1_client_1_1_i_statistics.html#a86182b8145c3178ef1babac226fdb912", null ],
    [ "OutMsgs", "interface_n_a_t_s_1_1_client_1_1_i_statistics.html#a6338566315b5d0f8099a4ec37db65360", null ],
    [ "Reconnects", "interface_n_a_t_s_1_1_client_1_1_i_statistics.html#a347a34f400e29b902bb46de856e3f0ff", null ]
];