var interface_n_a_t_s_1_1_client_1_1_i_sync_subscription =
[
    [ "NextMessage", "interface_n_a_t_s_1_1_client_1_1_i_sync_subscription.html#abff4071c0c522ca556f57ad899baa353", null ],
    [ "NextMessage", "interface_n_a_t_s_1_1_client_1_1_i_sync_subscription.html#a29d8865c23b821cc03aba53c700e4794", null ]
];