var searchData=
[
  ['getdefaultoptions_48',['GetDefaultOptions',['../class_n_a_t_s_1_1_client_1_1_connection_factory.html#aead806fcd34d9edbbc2fcaa3ada6b7c3',1,'NATS::Client::ConnectionFactory']]],
  ['getmaxpending_49',['GetMaxPending',['../interface_n_a_t_s_1_1_client_1_1_i_subscription.html#adcd1652be7ee61b34ceb4e009cc1b67c',1,'NATS.Client.ISubscription.GetMaxPending()'],['../class_n_a_t_s_1_1_client_1_1_subscription.html#a57771f325ac0b1f2a09c85dc7d42dfb1',1,'NATS.Client.Subscription.GetMaxPending()']]],
  ['getpending_50',['GetPending',['../interface_n_a_t_s_1_1_client_1_1_i_subscription.html#aedf741af5c64fcdf2897f101608b5a52',1,'NATS.Client.ISubscription.GetPending()'],['../class_n_a_t_s_1_1_client_1_1_subscription.html#a3fed52bf847e69bd44d15aea22b17fa4',1,'NATS.Client.Subscription.GetPending()']]]
];
