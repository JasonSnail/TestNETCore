var searchData=
[
  ['msg_199',['Msg',['../class_n_a_t_s_1_1_client_1_1_msg.html',1,'NATS::Client']]],
  ['msghandlereventargs_200',['MsgHandlerEventArgs',['../class_n_a_t_s_1_1_client_1_1_msg_handler_event_args.html',1,'NATS::Client']]]
];
