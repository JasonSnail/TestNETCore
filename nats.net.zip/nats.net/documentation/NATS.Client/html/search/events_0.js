var searchData=
[
  ['messagehandler_377',['MessageHandler',['../class_n_a_t_s_1_1_client_1_1_async_subscription.html#a94fe152738a09d19624aae569a1c7eac',1,'NATS.Client.AsyncSubscription.MessageHandler()'],['../interface_n_a_t_s_1_1_client_1_1_i_async_subscription.html#ac6c7bc56443b70ae0743f94be94b119e',1,'NATS.Client.IAsyncSubscription.MessageHandler()']]]
];
