var searchData=
[
  ['msg_258',['Msg',['../class_n_a_t_s_1_1_client_1_1_msg.html#acc18756be7b885968f07e9deed1944fe',1,'NATS.Client.Msg.Msg()'],['../class_n_a_t_s_1_1_client_1_1_msg.html#a3ac0078d9df661e813043e2a39661360',1,'NATS.Client.Msg.Msg(string subject, string reply, byte[] data)'],['../class_n_a_t_s_1_1_client_1_1_msg.html#a050180d86545f5b766f47e1bebd1f776',1,'NATS.Client.Msg.Msg(string subject, byte[] data)'],['../class_n_a_t_s_1_1_client_1_1_msg.html#aa350543d1cc03914d6f2b7ed48f1e1a7',1,'NATS.Client.Msg.Msg(string subject)']]]
];
