var searchData=
[
  ['allowreconnect_306',['AllowReconnect',['../class_n_a_t_s_1_1_client_1_1_options.html#aca0e26d763c9b7920eeb2506bfffc59b',1,'NATS::Client::Options']]],
  ['arrivalsubcription_307',['ArrivalSubcription',['../class_n_a_t_s_1_1_client_1_1_msg.html#a5abab008521e1950c41163a06e20ec78',1,'NATS::Client::Msg']]]
];
