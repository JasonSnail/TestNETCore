var searchData=
[
  ['data_313',['Data',['../class_n_a_t_s_1_1_client_1_1_msg.html#ac4deb024e50d441e9b20da3466b1309d',1,'NATS::Client::Msg']]],
  ['delivered_314',['Delivered',['../interface_n_a_t_s_1_1_client_1_1_i_subscription.html#a97e96a370cb01dd6808b7f90cbf4b886',1,'NATS.Client.ISubscription.Delivered()'],['../class_n_a_t_s_1_1_client_1_1_subscription.html#a83105d639605774d4c5d6b55f39a96dc',1,'NATS.Client.Subscription.Delivered()']]],
  ['discoveredservers_315',['DiscoveredServers',['../class_n_a_t_s_1_1_client_1_1_connection.html#a457bf749c7e6046a8080e3feabdaa79e',1,'NATS.Client.Connection.DiscoveredServers()'],['../interface_n_a_t_s_1_1_client_1_1_i_connection.html#af67e98d92452ead23d62cd51ebc0191a',1,'NATS.Client.IConnection.DiscoveredServers()'],['../interface_n_a_t_s_1_1_client_1_1_i_encoded_connection.html#abce06b5b3d539eedd4f7be924851b15a',1,'NATS.Client.IEncodedConnection.DiscoveredServers()']]],
  ['dropped_316',['Dropped',['../interface_n_a_t_s_1_1_client_1_1_i_subscription.html#abf4058acb532e468c9283c6498a3bb3b',1,'NATS.Client.ISubscription.Dropped()'],['../class_n_a_t_s_1_1_client_1_1_subscription.html#a69c2e09909771a613bece5998c5e400c',1,'NATS.Client.Subscription.Dropped()']]]
];
