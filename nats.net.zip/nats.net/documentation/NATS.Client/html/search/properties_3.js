var searchData=
[
  ['error_317',['Error',['../class_n_a_t_s_1_1_client_1_1_conn_event_args.html#a83a9998fd0824b3c326ecfbeba99b435',1,'NATS.Client.ConnEventArgs.Error()'],['../class_n_a_t_s_1_1_client_1_1_err_event_args.html#aaf69826de4c5910c4b4a2f4f5d5f36c9',1,'NATS.Client.ErrEventArgs.Error()']]]
];
