var searchData=
[
  ['inbytes_318',['InBytes',['../interface_n_a_t_s_1_1_client_1_1_i_statistics.html#ad9fbd5ee688b23449991d2a3abc0c7ea',1,'NATS.Client.IStatistics.InBytes()'],['../class_n_a_t_s_1_1_client_1_1_statistics.html#a05c477b2f999fe862739c7c608e83c69',1,'NATS.Client.Statistics.InBytes()']]],
  ['inmsgs_319',['InMsgs',['../interface_n_a_t_s_1_1_client_1_1_i_statistics.html#a57a64591aa59219d379a8074479d0dbb',1,'NATS.Client.IStatistics.InMsgs()'],['../class_n_a_t_s_1_1_client_1_1_statistics.html#a3ba3c1577ac461228e35c7dab8334a6c',1,'NATS.Client.Statistics.InMsgs()']]],
  ['instance_320',['Instance',['../class_n_a_t_s_1_1_client_1_1_n_u_i_d.html#a1a90d871c96ce5d107eb7184485a5dc8',1,'NATS::Client::NUID']]],
  ['isvalid_321',['IsValid',['../interface_n_a_t_s_1_1_client_1_1_i_subscription.html#a91c05cbdf2710acf1388bfe998107e86',1,'NATS.Client.ISubscription.IsValid()'],['../class_n_a_t_s_1_1_client_1_1_subscription.html#a3042e77473ff789028999d7e23df3862',1,'NATS.Client.Subscription.IsValid()']]]
];
