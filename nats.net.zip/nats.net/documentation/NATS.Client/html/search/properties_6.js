var searchData=
[
  ['lasterror_323',['LastError',['../class_n_a_t_s_1_1_client_1_1_connection.html#a65d51efdae179e6b5e06ae2a476cb632',1,'NATS.Client.Connection.LastError()'],['../interface_n_a_t_s_1_1_client_1_1_i_connection.html#a97322f6714fe27d8ad10a618cc70b9ea',1,'NATS.Client.IConnection.LastError()'],['../interface_n_a_t_s_1_1_client_1_1_i_encoded_connection.html#a68d8dc5bb51d31ccf178e5b4612924ab',1,'NATS.Client.IEncodedConnection.LastError()']]],
  ['length_324',['Length',['../class_n_a_t_s_1_1_client_1_1_n_u_i_d.html#ac5607c757e78f5206e4c3498a595790e',1,'NATS::Client::NUID']]]
];
