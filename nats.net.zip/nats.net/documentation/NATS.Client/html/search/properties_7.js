var searchData=
[
  ['maxpayload_325',['MaxPayload',['../class_n_a_t_s_1_1_client_1_1_connection.html#aa24c56612d2ba797c743870d30d909ce',1,'NATS.Client.Connection.MaxPayload()'],['../interface_n_a_t_s_1_1_client_1_1_i_connection.html#adf18200f0d9177ed2d2a65b05e467c69',1,'NATS.Client.IConnection.MaxPayload()'],['../interface_n_a_t_s_1_1_client_1_1_i_encoded_connection.html#a003a364e409ee49a25e22b9144504c04',1,'NATS.Client.IEncodedConnection.MaxPayload()']]],
  ['maxpendingbytes_326',['MaxPendingBytes',['../interface_n_a_t_s_1_1_client_1_1_i_subscription.html#ac4b99a8ce31bffd5f7a1bd3fd3c5a67b',1,'NATS.Client.ISubscription.MaxPendingBytes()'],['../class_n_a_t_s_1_1_client_1_1_subscription.html#a5662f61b7c25dea019fd0947aa038f04',1,'NATS.Client.Subscription.MaxPendingBytes()']]],
  ['maxpendingmessages_327',['MaxPendingMessages',['../interface_n_a_t_s_1_1_client_1_1_i_subscription.html#a446168a33a8b8036ad8fff46e1d90b39',1,'NATS.Client.ISubscription.MaxPendingMessages()'],['../class_n_a_t_s_1_1_client_1_1_subscription.html#a9ae322ed533cba343cf7b83c9cf82af6',1,'NATS.Client.Subscription.MaxPendingMessages()']]],
  ['maxpingsout_328',['MaxPingsOut',['../class_n_a_t_s_1_1_client_1_1_options.html#af72a56c42d59f70432c80f8526edda6e',1,'NATS::Client::Options']]],
  ['maxreconnect_329',['MaxReconnect',['../class_n_a_t_s_1_1_client_1_1_options.html#a6879755fbefbc3c119c01eb1e1e7f183',1,'NATS::Client::Options']]],
  ['message_330',['Message',['../class_n_a_t_s_1_1_client_1_1_encoded_message_event_args.html#addeff0383437b18da543e4feb616f591',1,'NATS.Client.EncodedMessageEventArgs.Message()'],['../class_n_a_t_s_1_1_client_1_1_msg_handler_event_args.html#a567878c50e019bf1bc3d190c923109a8',1,'NATS.Client.MsgHandlerEventArgs.Message()']]]
];
