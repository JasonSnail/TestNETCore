var searchData=
[
  ['queue_351',['Queue',['../interface_n_a_t_s_1_1_client_1_1_i_subscription.html#a3e505b346b8dc6339e84059441d9b1f4',1,'NATS.Client.ISubscription.Queue()'],['../class_n_a_t_s_1_1_client_1_1_subscription.html#ad275b73355ef820f9ce461689170c028',1,'NATS.Client.Subscription.Queue()']]],
  ['queuedmessagecount_352',['QueuedMessageCount',['../interface_n_a_t_s_1_1_client_1_1_i_subscription.html#ab474bbe759abcb118e92890918b78fb8',1,'NATS.Client.ISubscription.QueuedMessageCount()'],['../class_n_a_t_s_1_1_client_1_1_subscription.html#a9ec19bba2b4606d7791a0db697baf962',1,'NATS.Client.Subscription.QueuedMessageCount()']]]
];
