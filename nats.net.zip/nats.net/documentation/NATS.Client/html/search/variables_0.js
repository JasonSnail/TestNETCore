var searchData=
[
  ['asyncerroreventhandler_283',['AsyncErrorEventHandler',['../class_n_a_t_s_1_1_client_1_1_options.html#a2df13bb7ca6daac4fda3afd097cb6f82',1,'NATS::Client::Options']]]
];
