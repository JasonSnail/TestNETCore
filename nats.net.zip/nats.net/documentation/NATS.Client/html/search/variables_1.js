var searchData=
[
  ['closedeventhandler_284',['ClosedEventHandler',['../class_n_a_t_s_1_1_client_1_1_options.html#a910d4dcebe9046e2ab1772f2007dce0e',1,'NATS::Client::Options']]],
  ['credsfile_285',['CredsFile',['../class_n_a_t_s_1_1_client_1_1_default_user_j_w_t_handler.html#ab5a38c86be52043de71ffc00c670436c',1,'NATS::Client::DefaultUserJWTHandler']]]
];
