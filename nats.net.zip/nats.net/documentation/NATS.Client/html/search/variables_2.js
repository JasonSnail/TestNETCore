var searchData=
[
  ['disconnectedeventhandler_286',['DisconnectedEventHandler',['../class_n_a_t_s_1_1_client_1_1_options.html#a6116c0a92a645bbc356bde9533220ea4',1,'NATS::Client::Options']]]
];
