var searchData=
[
  ['maxpre_289',['MAXPRE',['../class_n_a_t_s_1_1_client_1_1_n_u_i_d.html#a0cd2a8d4606f781aff89138583064441',1,'NATS::Client::NUID']]],
  ['maxseq_290',['MAXSEQ',['../class_n_a_t_s_1_1_client_1_1_n_u_i_d.html#a3206287467c3d9d72841d8016e958bf6',1,'NATS::Client::NUID']]]
];
