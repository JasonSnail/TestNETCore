var searchData=
[
  ['reconnectbufferdisabled_291',['ReconnectBufferDisabled',['../class_n_a_t_s_1_1_client_1_1_options.html#abef6efbc8be65c0894eec97119964f0b',1,'NATS::Client::Options']]],
  ['reconnectbuffersizeunbounded_292',['ReconnectBufferSizeUnbounded',['../class_n_a_t_s_1_1_client_1_1_options.html#a3c59b6afb8a232bcf9696badbc9bd136',1,'NATS::Client::Options']]],
  ['reconnectedeventhandler_293',['ReconnectedEventHandler',['../class_n_a_t_s_1_1_client_1_1_options.html#ad39b3eec90490ebaa53276fc01668d9a',1,'NATS::Client::Options']]],
  ['reconnectforever_294',['ReconnectForever',['../class_n_a_t_s_1_1_client_1_1_options.html#a3db33f1a9202060929cf2cac1b63f3a4',1,'NATS::Client::Options']]]
];
