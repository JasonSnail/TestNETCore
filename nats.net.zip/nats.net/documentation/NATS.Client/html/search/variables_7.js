var searchData=
[
  ['serverdiscoveredeventhandler_295',['ServerDiscoveredEventHandler',['../class_n_a_t_s_1_1_client_1_1_options.html#a01dd0d8f7f5cabdc5d2d68c08dff3561',1,'NATS::Client::Options']]],
  ['subscriptioncount_296',['SubscriptionCount',['../class_n_a_t_s_1_1_client_1_1_connection.html#a8c242e1875cea6af987519d501e7dc13',1,'NATS::Client::Connection']]]
];
