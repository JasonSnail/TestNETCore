var searchData=
[
  ['tlsremotecertificationvalidationcallback_297',['TLSRemoteCertificationValidationCallback',['../class_n_a_t_s_1_1_client_1_1_options.html#a3ee9fbb7b3cfbc49a9b3a314f883904d',1,'NATS::Client::Options']]]
];
