﻿// Copyright 2020 The NATS Authors
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

using BenchmarkDotNet.Attributes;
using BenchmarkDotNet.Jobs;
using BenchmarkDotNet.Order;
using NATS.Client;
using NATS.Client.Internals;

namespace MicroBenchmarks
{
    [DisassemblyDiagnoser(printSource: true)]
    [Orderer(SummaryOrderPolicy.FastestToSlowest)]
    [MemoryDiagnoser]
    [MarkdownExporterAttribute.GitHub]
    [SimpleJob(RuntimeMoniker.Net462)]
    [SimpleJob(RuntimeMoniker.NetCoreApp31)]
    public class NuidBenchmark
    {
#pragma warning disable CS0618
        private readonly NUID _nuid = NUID.Instance;
#pragma warning restore CS0618
        private readonly Nuid _newNuid = new Nuid(null, 0, 1);

        public NuidBenchmark()
        {
            _nuid.Seq = 0;
        }

        [BenchmarkCategory("NextNuid")]
        [Benchmark(Baseline = true)]
        public string NUIDNext() => _nuid.Next;

        [BenchmarkCategory("NextNuid"), Benchmark]
        public string NextNuid() => _newNuid.GetNext();
    }
}
